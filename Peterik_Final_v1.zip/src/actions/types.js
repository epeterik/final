export const UPDATE_TOP_HEADLINES = "Update-Top-Headlines"; //News API
export const UPDATE_SUBSCRIBED_HEADLINES = "Update-Subscribed-Headlines"; //Mock API
export const UPDATE_CATEGORIZED_HEADLINES = "Update-Categorized-Headlines"; // News API

export const SET_SELECTED_ARTICLE_CATEGORY = "Set-Selected-Article-Category"; //User Input