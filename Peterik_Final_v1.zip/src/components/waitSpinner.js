import React from 'react';
import '../ui-toolkit/css/nm-cx/main.css';

export const WaitSpinner = (props) => {
    return (
        <div className="text-center">
            <span className="loading-indicator xlarge"></span>
        </div>
        );
}